import React from 'react';
import Route from './route';
import Header from './fortend/header'
function App() {
  return (
    <div className="App">
      <Header/>
      <Route/>
    
    </div>
  );
}

export default App;
