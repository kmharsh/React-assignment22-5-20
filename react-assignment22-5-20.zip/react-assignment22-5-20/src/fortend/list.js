import React from 'react';
import { Link } from 'react-router-dom';

import './style.css';
class Search extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
        error : null,
        data:[],
        serachValue: '',
    }
}
componentDidMount() {
  const apiUrl = 'https://jsonplaceholder.typicode.com/posts';
 
  fetch(apiUrl)
  .then( response => response.json() )
  .then( 
      (result) => {
        this.setState({ data :  result })
          //console.log(result);
         
      },
      (error) => {
          this.setState({ error : error })
      }
   )
   
};


// --------------------------Search----------------------------///
onChangeKeyword = e => {
  this.setState({ serachValue: e.target.value });
};

onSearchSubmit = e => {
  const that = this;
  e.preventDefault();
  const apiData =
    "https://jsonplaceholder.typicode.com/posts?userId=" +
    that.state.serachValue;
  fetch(apiData)
    .then(res => res.json())
    .then(
      result => {
        this.setState({ data: result });
        console.log(this.state.data);
      },
      error => {
        this.setState({ error: error });
      }
    );
};

////-----------------------Search----------------------------////


  
render() {
  const { serachValue } = this.state;
  const { data } = this.state;
  return (
   
    <div className="container">
       
      <h1>Search Page</h1>
      <div>
        <form onClick={this.onSearchSubmit}>
          <label>
            <input
              type="search"
              name="serachValue" placeholder="UserId"
              onChange={this.onChangeKeyword}
              value={serachValue}
            />
          </label>
          <label>
            <input type="submit" value="search" />
          </label>
        </form>
      </div>

      <div className="table-show">
        { data.length > 0 && <table>
          <tr>
            <td>
              <table className="list" id="employeeList">
                <thead>
                  <tr>
                    <th>
                      <strong>Id</strong>
                    </th>
                    <th>
                      <strong>UserId</strong>
                    </th>
                    <th>
                      {" "}
                      <strong>Title</strong>
                    </th>
                    <th>
                      {" "}
                      <strong>Body</strong>
                    </th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {data.map(postData => (
                    <tr>
                      <td className="head-table">{postData.id}</td>
                      <td className="head-table">{postData.userId}</td>
                      <td className="head-table">{postData.title}</td>
                      <td className="head-table">{postData.body}</td>
                      <td>
                        <Link to={"/apply/"} className="btn">
                          {" "}
                          Apply{" "}
                        </Link>
                      </td>
                    </tr>
                  ))}
                  
                </tbody>
              </table>
            </td>
          </tr>
        </table>
        }
        {!data.length && <div>No Result found</div>}
      </div>
    </div>
  );
}

}

export default Search
  