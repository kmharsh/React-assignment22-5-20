import React, { Component } from 'react';

import './style.css';
class JobPostComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            jobTitle: '',
            industry: '',
            experience: '',
            skill1: false,
            skill2: false,
            skill3: false,
            skill4: false,
            skill5: false,
            locations: {
                1: 'Hydrabad',
                2: 'Noida',
                3: 'Gurugram',
                4: 'Pune',
                5: 'Mumbai'
            }
        }
    }

    changeHandler = e => {
        this.setState({
            [e.target.name]: e.target.value
        });
       
    };

    checkHandler = e => {
        this.setState({
            [e.target.name]: e.target.checked,
            [e.target.name]: e.target.value
        });
       
    }

    radioHandler = e => {
        this.setState({
            [e.target.name]: e.target.value
        });
        
    }

    postFormSubmit = (e) => {
        const data = this.state
        console.log(data);
        e.preventDefault();
        localStorage.setItem("data", JSON.stringify(data));
        this.props.history.push('/display', { data: this.state.data});
    }
    componentDidMount(){
        var comment = JSON.parse(localStorage.getItem('data'));
         console.log("data",comment);
        
       this.setState({data:comment});
      }
    render() {

        const { locations } = this.state;
        return (

            <section>
              
                <div className="container">
               
                    <div className="job-wrap">
                        <h2 >Post A New Job</h2>
                        <form method='post' onSubmit={this.postFormSubmit} >
                            <div className="from-dis" >
                                <div className="from-lbl" >
                                    <label>Job Title</label>
                                </div>
                                <div className="from-input" >
                                    <input type="text" autoComplete="off" name="jobTitle" onChange={this.changeHandler} value={this.state.jobTitle} />
                                </div>
                            </div>

                            <div className="from-dis">
                                <div className="from-lbl">
                                    <label>Industry Type</label>
                                </div>
                                <div className="from-input">
                                    <input type="text" name="industry" onChange={this.changeHandler} value={this.state.industry} />
                                </div>
                            </div>

                            <div className="from-dis">
                                <div className="from-lbl">
                                    <label>Experience</label>
                                </div>
                                <div className="from-input"> 
                                    <select name="experience" onChange={this.changeHandler} value={this.state.experience}>
                                        <option value=''>Select Experience</option>
                                        <option value='0 - 1 Year'>0 - 1 Year</option>
                                        <option value='1 - 3 Years'>1 - 3 Years</option>
                                        <option value='4 - 7 Years'>4 - 7 Years</option>
                                    </select>
                                </div>
                            </div>

                            <div className="from-dis">
                                <div className="from-lbl">
                                    <label>Required Skills</label>
                                </div>
                                <div className="frm-check">
                                    {

                                    }

                                    <label><input type="checkbox" name="skill1" checked={this.state.skill} onChange={this.checkHandler} value="HTML5" />HTML5</label>

                                    <label><input type="checkbox" name="skill2" checked={this.state.skill2} onChange={this.checkHandler} value="Css3" />Css3</label>

                                    <label><input type="checkbox" name="skill3" checked={this.state.skill3} onChange={this.checkHandler} value="Sass" />Sass</label>

                                    <label><input type="checkbox" name="skill4" checked={this.state.skill4} onChange={this.checkHandler} value="JavaScript" />JavaScript</label>

                                    <label><input type="checkbox" name="skill5" checked={this.state.skill5} onChange={this.checkHandler} value="React.js" />React.js</label>
                                </div>
                            </div>

                            <div className="from-dis">
                                <div className="from-lbl" >
                                    <label>Preferred Location</label>
                                </div>
                                <div className="frm-check">
                                    {
                                        locations && Object.values(locations).map((val, index) => {
                                            return (<label key={index}>
                                                <input type="radio"
                                                    name="location"
                                                    checked={this.state.location === val}
                                                    onChange={(e) => this.radioHandler(e)}
                                                    value={val} />
                                                {val}
                                            </label>)
                                        })
                                    }

                                </div>
                            </div>
                            <div className="from-dis">
                                <button type="submit">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        )
    }

}

export default JobPostComponent;
