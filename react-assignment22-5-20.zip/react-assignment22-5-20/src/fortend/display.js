import React, { Component } from 'react';

class Display extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: {}
    }
  }

  componentDidMount() {
    var getdata = this.props.location.state.data;
    console.log("data", getdata);
    this.setState({ data: getdata });
  }
  render() {

    return (
      <div>
        <div className="container">
          <div className="table-show">
            <table>
              <tr>
                <td>
                  <table className="tbl-wrap">
                    <thead>
                      <tr>
                        <th>
                          <strong>industry</strong>
                        </th>
                        <th>
                          <strong>experience</strong>
                        </th>
                        <th>
                          <strong>jobTitle</strong>
                        </th>
                        <th>
                          <strong>location</strong>
                        </th>
                        <th><strong>skill1</strong></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>{this.state.data.industry}</td>
                        <td>{this.state.data.experience}</td>
                        <td>{this.state.data.jobTitle}</td>
                        <td>{this.state.data.location}</td>
                        <td>{this.state.data.skill1}</td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
            </table>
       </div>
        </div>
      </div>
    );
  }
}

export default Display;