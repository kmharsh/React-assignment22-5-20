import React, { Component } from 'react';
import './style.css';
class Header extends Component {
  render() {
    return (
      <div>
          <nav>
              <ul>
                <li><a href="job">Jobs</a></li>
                <li><a href="display">Display</a></li>
                <li><a href="list">List</a></li>
              </ul>
            </nav>
      </div>
    );
  }
}

export default Header;