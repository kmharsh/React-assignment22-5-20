import React from 'react';
import { Switch, Route,  BrowserRouter as Router } from 'react-router-dom'

import Jobs from './fortend/job';
import List from './fortend/list';
import Display from './fortend/display';


const Routing = () => (
  <Router>
    <div>
    <Switch>
      <Route path="/job" component={Jobs} />
      <Route path="/list" component={List} />
      <Route path="/display" component={Display} />
      </Switch>
    </div>
  </Router>
);

export default Routing;
